#==========================fftw-3D in R========================================
#-----------------  Copyright (C) 2016 John Feng  -----------------------------
#
#   This file is a part of the package xps. This function extended fftwtools
#   package for 3D FFT.
#
#   The xps package is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 2 of the License, or
#   any later version.
#
#   The xps package is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#------------------------------------------------------------------------------

fftw3d <- function(data, inverse=0) {
    data <- as.array(data)
    nx <- dim(data)[1]
    ny <- dim(data)[2]
    nz <- dim(data)[3]

    rtn <- .C("fftw3d", as.integer(nz), as.integer(ny), as.integer(nx),
            as.complex(data),
            res=array(as.complex(0.0), dim=c(nx,ny,nz)),
            as.integer(inverse))

    return(rtn$res)
}
