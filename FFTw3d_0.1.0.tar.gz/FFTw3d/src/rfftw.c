//==========================fftw-3D in R========================================
//-----------------  Copyright (C) 2016 John Feng  -----------------------------
//
//   This file is a part of the package xps. It is a R wrapper of the FFTW.
//
//   The xps package is free software: you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation, either version 2 of the License, or
//   any later version.
//
//   The xps package is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty
//   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//------------------------------------------------------------------------------
#include<complex.h>
#include<fftw3.h>

void fftw3d(int* nz, int* ny, int*nx, double complex* data, double complex* res,
            int* inverse){
    int sign;
    fftw_plan p;

    if(*inverse == 1) {
        sign = FFTW_BACKWARD;
    } else {
        sign = FFTW_FORWARD;
    }

    p = fftw_plan_dft_3d(*nz, *ny, *nx, data, res, sign, FFTW_ESTIMATE);

    fftw_execute(p);

    fftw_destroy_plan(p);
}
